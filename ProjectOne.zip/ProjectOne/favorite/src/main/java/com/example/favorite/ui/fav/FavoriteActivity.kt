package com.example.favorite.ui.fav

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.favorite.databinding.ActivityFavoriteBinding
import com.example.projectone.ui.main.UserAdapter
import com.example.projectone.ui.userdetail.DetailUserActivity

class FavoriteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoriteBinding

    private val adapter by lazy {
        UserAdapter{

        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.FavoriteListRv.layoutManager = LinearLayoutManager(this)
        binding.FavoriteListRv.adapter = adapter

        // Inisialisasi ViewModel
        val viewModel = ViewModelProvider(this, FavoriteViewModelFactory(application)).get(
            FavoriteViewModel::class.java
        )

        // Mengamati LiveData dari ViewModel
        viewModel.getAllFavUser().observe(this) { favUsers ->
            // Update data dalam adapter
            adapter.setData(favUsers)
        }

    }
}


