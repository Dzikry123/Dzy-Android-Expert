package com.example.projectone.ui.userdetail

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.projectone.data.repo.FavoriteRepository
import com.example.projectone.domain.GithubUserRepositoryImpl
import com.example.projectone.domain.model.main.GithubDetailUser
import com.example.projectone.domain.model.main.GithubUser
import com.example.projectone.utils.ResultViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.launch
import javax.inject.Inject

    @HiltViewModel
    class DetailUserViewModel @Inject constructor(
        private val repository: GithubUserRepositoryImpl,
        private val favoriteRepository: FavoriteRepository
    ) : ViewModel() {

        val resultDetailUser = MutableLiveData<ResultViewModel>()
        val resultFavoriteAdd = MutableLiveData<ResultViewModel>()
        val resultFavoriteDelete = MutableLiveData<ResultViewModel>()

        private var cachedUserData: Triple<GithubDetailUser, MutableList<GithubUser.Item>, MutableList<GithubUser.Item>>? = null


        // LiveData untuk status favorit
        private val _isFavorite = MutableLiveData<Boolean>()
        val isFavorite: LiveData<Boolean> = _isFavorite

        fun insert(fav: GithubUser.Item) {
            favoriteRepository.insert(fav)
            _isFavorite.value = true
        }

        fun delete(fav: GithubUser.Item) {
            favoriteRepository.delete(fav)
            _isFavorite.value = false
        }

        fun findById(id: Int, function: () -> Unit) {
            viewModelScope.launch {
                val user = favoriteRepository.findById(id)
                if (user != null) {
                    function()
                    _isFavorite.value = true
                }
            }
        }

        // Mengambil detail user menggunakan Flow
        fun getUser(username: String) {
            viewModelScope.launch {
                flow {
                    emit(ResultViewModel.Loading(true))
                    val userDetail = repository.getDetailUserFromGithub(username)
                    val follower = repository.getFollowerUserFromGithub(username)
                    val following = repository.getFollowingUserFromGithub(username)
                    emit(ResultViewModel.Success(Triple(userDetail, follower, following)))

                }.catch { throwable ->
                    Log.e("Error", throwable.message.toString())
                    throwable.printStackTrace()
                    emit(ResultViewModel.Error(throwable))
                    Log.d("Get Data Detail", throwable.message.toString())
                }.onCompletion {
                    emit(ResultViewModel.Loading(false))
                }.collect { result ->
                    resultDetailUser.value = result
                }
            }
        }

        fun getCachedUserData(): Triple<GithubDetailUser, MutableList<GithubUser.Item>, MutableList<GithubUser.Item>>? {
            return cachedUserData
        }

        val resultFollowersUser = MutableLiveData<ResultViewModel>()
        val resultFollowingUser = MutableLiveData<ResultViewModel>()

        fun getFollowerUser(username: String) {
            viewModelScope.launch {
                try {
                    resultFollowersUser.value = ResultViewModel.Loading(true)
                    val response = repository.getFollowerUserFromGithub(username)
                    resultFollowersUser.value = ResultViewModel.Success(response)
                } catch (e: Exception) {
                    Log.e("Error", e.message.toString())
                    e.printStackTrace()
                    resultFollowersUser.value = ResultViewModel.Error(e)
                } finally {
                    resultFollowersUser.value = ResultViewModel.Loading(false)
                }
            }
        }

        fun getFollowingUser(username: String) {
            viewModelScope.launch {
                try {
                    resultFollowingUser.value = ResultViewModel.Loading(true)
                    val response = repository.getFollowingUserFromGithub(username)
                    resultFollowingUser.value = ResultViewModel.Success(response)
                } catch (e: Exception) {
                    Log.e("Error", e.message.toString())
                    e.printStackTrace()
                    resultFollowingUser.value = ResultViewModel.Error(e)
                } finally {
                    resultFollowingUser.value = ResultViewModel.Loading(false)
                }
            }
        }
    }

