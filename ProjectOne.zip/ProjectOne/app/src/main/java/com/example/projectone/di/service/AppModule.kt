package com.example.projectone.di.service

import android.content.Context
import com.example.projectone.data.repo.FavoriteRepository
import com.example.projectone.data.repo.GithubUserRepository
import com.example.projectone.domain.GithubUserRepositoryImpl
import com.example.projectone.ui.main.MainViewModel
import com.example.projectone.ui.userdetail.DetailUserViewModel
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {


    @Provides
    @Singleton
    fun provideGithubUserListRepository(service: ServiceGithub): GithubUserRepository {
        return GithubUserRepositoryImpl(service)
    }

    @Provides
    @Singleton
    fun provideFavoriteRepository(@ApplicationContext context: Context): FavoriteRepository {
        return FavoriteRepository(context)
    }

    @Provides
    @Singleton
    fun provideMainViewModel(repository: GithubUserRepositoryImpl): MainViewModel {
        return MainViewModel(repository)
    }

    @Provides
    @Singleton
    fun provideDetailUserViewModel(
        repository: GithubUserRepositoryImpl,
        favoriteRepository: FavoriteRepository
    ) : DetailUserViewModel {
        return DetailUserViewModel(repository, favoriteRepository)
    }

//    @Provides
//    @Singleton
//    fun provideFavoriteViewModel(repository: FavoriteRepository): FavoriteViewModel {
//        return FavoriteViewModel(repository)
//    }

    @Provides
    @Singleton
    fun provideServiceGithub(): ServiceGithub {
        return ApiClient.githubService
    }

}