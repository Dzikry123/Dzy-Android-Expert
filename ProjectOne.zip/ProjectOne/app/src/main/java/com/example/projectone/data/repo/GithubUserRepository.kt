package com.example.projectone.data.repo

import com.example.projectone.data.model.ResponseDetailUserGithub
import com.example.projectone.data.model.ResponseUserGithub
import com.example.projectone.domain.model.main.GithubDetailUser
import com.example.projectone.domain.model.main.GithubUser

// GithubUserRepository
interface GithubUserRepository {
    suspend fun getUserFromGithub(): MutableList<GithubUser.Item>
    suspend fun searchUserFromGithub(username: String): GithubUser

    suspend fun getDetailUserFromGithub(username: String): GithubDetailUser
    suspend fun getFollowerUserFromGithub(username: String): MutableList<GithubUser.Item>
    suspend fun getFollowingUserFromGithub(username: String): MutableList<GithubUser.Item>
}
