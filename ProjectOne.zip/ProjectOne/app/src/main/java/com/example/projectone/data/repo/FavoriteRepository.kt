package com.example.projectone.data.repo

import android.content.Context
import androidx.lifecycle.LiveData
import com.example.projectone.data.db.FavDao
import com.example.projectone.data.db.FavDb
import com.example.projectone.data.model.ResponseUserGithub
import com.example.projectone.domain.model.main.GithubUser
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import javax.inject.Inject

class FavoriteRepository @Inject constructor(@ApplicationContext private val context: Context) {

    private val mFavDao: FavDao
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()

    init {
        val db = FavDb.getDatabase(context)
        mFavDao = db.FavDao()
    }
    fun getAllFavUser(): LiveData<MutableList<GithubUser.Item>> = mFavDao.loadAll()
    fun insert(fav: GithubUser.Item) {
        executorService.execute { mFavDao.insertFav(fav) }
    }
    fun delete(fav: GithubUser.Item) {
        executorService.execute { mFavDao.deleteFav(fav) }
    }


    suspend fun findById(id: Int): GithubUser.Item? {
        return withContext(Dispatchers.IO) {
            mFavDao.findByid(id)
        }
    }

}

